package com.crisis.servlet;

import com.crisis.dao.AlertDAO;
import com.crisis.model.Alert;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.List;

@WebServlet("/alerts")
public class AlertServlet extends HttpServlet {

    private boolean checkSession(HttpServletRequest req, HttpServletResponse res)
            throws IOException {
        HttpSession session = req.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            res.sendRedirect("login");
            return false;
        }
        return true;
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!checkSession(req, res)) return;
        String action = req.getParameter("action");
        if (action == null) action = "list";
        AlertDAO dao = new AlertDAO();
        try {
            switch (action) {
                case "list":
                    String keyword     = req.getParameter("search");
                    String filterType  = req.getParameter("type");
                    String filterStatus= req.getParameter("status");
                    List<Alert> alerts;
                    if ((keyword != null && !keyword.isEmpty())
                            || (filterType  != null && !filterType.isEmpty())
                            || (filterStatus!= null && !filterStatus.isEmpty())) {
                        alerts = dao.searchAlerts(
                            keyword != null ? keyword : "", filterType, filterStatus);
                        req.setAttribute("search",       keyword);
                        req.setAttribute("filterType",   filterType);
                        req.setAttribute("filterStatus", filterStatus);
                    } else {
                        alerts = dao.getAllAlerts();
                    }
                    req.setAttribute("alerts",          alerts);
                    req.setAttribute("activeCount",     dao.countByStatus("ACTIVE"));
                    req.setAttribute("monitoringCount", dao.countByStatus("MONITORING"));
                    req.setAttribute("resolvedCount",   dao.countByStatus("RESOLVED"));
                    req.setAttribute("totalAffected",   dao.totalAffected());
                    req.getRequestDispatcher("dashboard.jsp").forward(req, res);
                    break;

                case "new":
                    req.getRequestDispatcher("alert_form.jsp").forward(req, res);
                    break;

                case "edit":
                    req.setAttribute("alert",
                        dao.getAlertById(Integer.parseInt(req.getParameter("id"))));
                    req.getRequestDispatcher("alert_form.jsp").forward(req, res);
                    break;

                case "view":
                    req.setAttribute("alert",
                        dao.getAlertById(Integer.parseInt(req.getParameter("id"))));
                    req.getRequestDispatcher("alert_detail.jsp").forward(req, res);
                    break;

                case "delete":
                    dao.deleteAlert(Integer.parseInt(req.getParameter("id")));
                    res.sendRedirect("alerts");
                    break;

                case "logout":
                    req.getSession().invalidate();
                    res.sendRedirect("login");
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("alerts");
        }
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        if (!checkSession(req, res)) return;
        String action = req.getParameter("action");
        AlertDAO dao  = new AlertDAO();
        try {
            Alert a = new Alert();
            a.setTitle(req.getParameter("title"));
            a.setDisasterType(req.getParameter("disaster_type"));
            a.setSeverity(req.getParameter("severity"));
            a.setLocation(req.getParameter("location"));
            a.setDescription(req.getParameter("description"));
            a.setAffectedCount(Integer.parseInt(req.getParameter("affected_count")));
            a.setStatus(req.getParameter("status"));
            a.setReportedBy((String) req.getSession().getAttribute("user"));

            if ("add".equals(action)) {
                dao.addAlert(a);
            } else if ("edit".equals(action)) {
                a.setId(Integer.parseInt(req.getParameter("id")));
                dao.updateAlert(a);
            }
            res.sendRedirect("alerts");
        } catch (Exception e) {
            e.printStackTrace();
            res.sendRedirect("alerts");
        }
    }
}