package com.crisis.servlet;

import com.crisis.dao.AlertDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("login.jsp").forward(req, res);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        try {
            AlertDAO dao = new AlertDAO();
            if (dao.validateLogin(username, password)) {
                HttpSession session = req.getSession();
                session.setAttribute("user", username);
                session.setAttribute("fullName", dao.getFullName(username));
                res.sendRedirect("alerts");
            } else {
                req.setAttribute("error", "Invalid User — Access Denied");
                req.getRequestDispatcher("login.jsp").forward(req, res);
            }
        } catch (Exception e) {
            req.setAttribute("error", "DB Error: " + e.getMessage());
            req.getRequestDispatcher("login.jsp").forward(req, res);
        }
    }
}