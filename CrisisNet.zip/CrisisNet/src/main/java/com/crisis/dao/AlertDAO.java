package com.crisis.dao;

import com.crisis.model.Alert;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlertDAO {

    private Alert mapRow(ResultSet rs) throws SQLException {
        Alert a = new Alert();
        a.setId(rs.getInt("id"));
        a.setTitle(rs.getString("title"));
        a.setDisasterType(rs.getString("disaster_type"));
        a.setSeverity(rs.getString("severity"));
        a.setLocation(rs.getString("location"));
        a.setDescription(rs.getString("description"));
        a.setAffectedCount(rs.getInt("affected_count"));
        a.setStatus(rs.getString("status"));
        a.setReportedBy(rs.getString("reported_by"));
        a.setReportedAt(rs.getTimestamp("reported_at"));
        a.setUpdatedAt(rs.getTimestamp("updated_at"));
        return a;
    }

    public List<Alert> getAllAlerts() throws Exception {
        List<Alert> list = new ArrayList<>();
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT * FROM alerts ORDER BY reported_at DESC");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) list.add(mapRow(rs));
        conn.close();
        return list;
    }

    public List<Alert> searchAlerts(String keyword, String filterType,
                                    String filterStatus) throws Exception {
        List<Alert> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT * FROM alerts WHERE (title LIKE ? OR location LIKE ? OR description LIKE ?)");
        if (filterType != null && !filterType.isEmpty())
            sql.append(" AND disaster_type = '").append(filterType).append("'");
        if (filterStatus != null && !filterStatus.isEmpty())
            sql.append(" AND status = '").append(filterStatus).append("'");
        sql.append(" ORDER BY reported_at DESC");
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql.toString());
        String kw = "%" + keyword + "%";
        ps.setString(1, kw); ps.setString(2, kw); ps.setString(3, kw);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) list.add(mapRow(rs));
        conn.close();
        return list;
    }

    public Alert getAlertById(int id) throws Exception {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT * FROM alerts WHERE id = ?");
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        Alert a = rs.next() ? mapRow(rs) : null;
        conn.close();
        return a;
    }

    public void addAlert(Alert a) throws Exception {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "INSERT INTO alerts (title, disaster_type, severity, location, " +
            "description, affected_count, status, reported_by) VALUES (?,?,?,?,?,?,?,?)");
        ps.setString(1, a.getTitle());
        ps.setString(2, a.getDisasterType());
        ps.setString(3, a.getSeverity());
        ps.setString(4, a.getLocation());
        ps.setString(5, a.getDescription());
        ps.setInt(6, a.getAffectedCount());
        ps.setString(7, a.getStatus());
        ps.setString(8, a.getReportedBy());
        ps.executeUpdate();
        conn.close();
    }

    public void updateAlert(Alert a) throws Exception {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "UPDATE alerts SET title=?, disaster_type=?, severity=?, location=?, " +
            "description=?, affected_count=?, status=? WHERE id=?");
        ps.setString(1, a.getTitle());
        ps.setString(2, a.getDisasterType());
        ps.setString(3, a.getSeverity());
        ps.setString(4, a.getLocation());
        ps.setString(5, a.getDescription());
        ps.setInt(6, a.getAffectedCount());
        ps.setString(7, a.getStatus());
        ps.setInt(8, a.getId());
        ps.executeUpdate();
        conn.close();
    }

    public void deleteAlert(int id) throws Exception {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "DELETE FROM alerts WHERE id = ?");
        ps.setInt(1, id);
        ps.executeUpdate();
        conn.close();
    }

    public boolean validateLogin(String username, String password) throws Exception {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT id FROM admin_users WHERE username=? AND password=?");
        ps.setString(1, username);
        ps.setString(2, password);
        boolean valid = ps.executeQuery().next();
        conn.close();
        return valid;
    }

    public String getFullName(String username) throws Exception {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT full_name FROM admin_users WHERE username=?");
        ps.setString(1, username);
        ResultSet rs = ps.executeQuery();
        String name = rs.next() ? rs.getString("full_name") : username;
        conn.close();
        return name;
    }

    public int countByStatus(String status) throws Exception {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT COUNT(*) FROM alerts WHERE status=?");
        ps.setString(1, status);
        ResultSet rs = ps.executeQuery();
        int count = rs.next() ? rs.getInt(1) : 0;
        conn.close();
        return count;
    }

    public int totalAffected() throws Exception {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(
            "SELECT SUM(affected_count) FROM alerts WHERE status != 'RESOLVED'");
        ResultSet rs = ps.executeQuery();
        int count = rs.next() ? rs.getInt(1) : 0;
        conn.close();
        return count;
    }
}