package com.crisis.model;

import java.sql.Timestamp;

public class Alert {
    private int id;
    private String title;
    private String disasterType;
    private String severity;
    private String location;
    private String description;
    private int affectedCount;
    private String status;
    private String reportedBy;
    private Timestamp reportedAt;
    private Timestamp updatedAt;

    public int getId()                     { return id; }
    public void setId(int id)              { this.id = id; }

    public String getTitle()               { return title; }
    public void setTitle(String t)         { this.title = t; }

    public String getDisasterType()        { return disasterType; }
    public void setDisasterType(String d)  { this.disasterType = d; }

    public String getSeverity()            { return severity; }
    public void setSeverity(String s)      { this.severity = s; }

    public String getLocation()            { return location; }
    public void setLocation(String l)      { this.location = l; }

    public String getDescription()         { return description; }
    public void setDescription(String d)   { this.description = d; }

    public int getAffectedCount()          { return affectedCount; }
    public void setAffectedCount(int a)    { this.affectedCount = a; }

    public String getStatus()              { return status; }
    public void setStatus(String s)        { this.status = s; }

    public String getReportedBy()          { return reportedBy; }
    public void setReportedBy(String r)    { this.reportedBy = r; }

    public Timestamp getReportedAt()       { return reportedAt; }
    public void setReportedAt(Timestamp t) { this.reportedAt = t; }

    public Timestamp getUpdatedAt()        { return updatedAt; }
    public void setUpdatedAt(Timestamp t)  { this.updatedAt = t; }
}