<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="com.crisis.model.Alert, java.util.List" %>
<%
  if (session.getAttribute("user") == null) { response.sendRedirect("login"); return; }
  List<Alert> alerts      = (List<Alert>) request.getAttribute("alerts");
  int activeCount         = (Integer) request.getAttribute("activeCount");
  int monitoringCount     = (Integer) request.getAttribute("monitoringCount");
  int resolvedCount       = (Integer) request.getAttribute("resolvedCount");
  int totalAffected       = (Integer) request.getAttribute("totalAffected");
  String search           = (String)  request.getAttribute("search");
  String filterType       = (String)  request.getAttribute("filterType");
  String filterStatus     = (String)  request.getAttribute("filterStatus");
  int totalAlerts         = (alerts != null) ? alerts.size() : 0;
%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280, initial-scale=1.0">
<title>CrisisNet — Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
html { font-size:18px; }
body { font-family:'Inter',sans-serif; background:#f5f5f5; color:#1a1a1a; }

/* NAVBAR */
.navbar {
  background:#b71c1c;
  padding:0 40px; height:80px;
  display:flex; align-items:center; justify-content:space-between;
  position:sticky; top:0; z-index:100;
  box-shadow:0 3px 12px rgba(0,0,0,0.15);
}
.nav-left  { display:flex; align-items:center; gap:16px; }
.nav-icon  { font-size:38px; }
.nav-title { color:#fff; font-size:32px; font-weight:900; letter-spacing:0.02em; }
.nav-right { display:flex; align-items:center; gap:20px; }
.officer-name {
  background:rgba(255,255,255,0.18); border-radius:30px;
  padding:10px 28px; color:#fff; font-size:22px; font-weight:700;
}
.btn-logout {
  background:#fff; color:#b71c1c; border-radius:10px;
  padding:11px 28px; font-size:22px; font-weight:800;
  text-decoration:none; transition:all 0.2s;
}
.btn-logout:hover { background:#ffebee; color:#b71c1c; }

/* PAGE */
.page { padding:40px 44px; }

/* PAGE HEADER */
.page-hdr {
  display:flex; align-items:center; justify-content:space-between;
  margin-bottom:36px;
}
.page-hdr h2 {
  font-size:38px; font-weight:900; color:#1a1a1a;
  display:flex; align-items:center; gap:14px;
}
.page-hdr h2 i { color:#b71c1c; font-size:38px; }
.btn-report {
  background:#b71c1c; color:#fff; border:none;
  border-radius:12px; padding:18px 40px;
  font-size:24px; font-weight:900;
  text-decoration:none; display:flex; align-items:center; gap:12px;
  transition:background 0.2s; font-family:'Inter',sans-serif;
}
.btn-report:hover { background:#c62828; color:#fff; }

/* STAT CARDS */
.stat-grid {
  display:grid; grid-template-columns:repeat(4,1fr);
  gap:26px; margin-bottom:34px;
}
.stat-card {
  background:#fff; border-radius:16px; padding:32px 28px;
  border-left:8px solid #ccc;
  box-shadow:0 2px 10px rgba(0,0,0,0.07);
  display:flex; align-items:center; gap:24px;
  transition:transform 0.2s;
}
.stat-card:hover { transform:translateY(-4px); }
.stat-card.red    { border-left-color:#e53935; }
.stat-card.amber  { border-left-color:#fb8c00; }
.stat-card.green  { border-left-color:#2e7d32; }
.stat-card.blue   { border-left-color:#1565c0; }
.stat-emoji { font-size:52px; }
.stat-num {
  font-size:52px; font-weight:900; line-height:1;
  margin-bottom:6px;
}
.stat-card.red   .stat-num { color:#e53935; }
.stat-card.amber .stat-num { color:#fb8c00; }
.stat-card.green .stat-num { color:#2e7d32; }
.stat-card.blue  .stat-num { color:#1565c0; }
.stat-lbl {
  font-size:20px; font-weight:700; color:#757575;
  text-transform:uppercase; letter-spacing:0.05em;
}

/* FILTER BAR */
.filter-bar {
  background:#fff; border-radius:14px; padding:26px 30px;
  box-shadow:0 2px 10px rgba(0,0,0,0.07); margin-bottom:28px;
  display:flex; align-items:center; gap:20px; flex-wrap:wrap;
}
.search-wrap { flex:1; min-width:300px; }
.filter-bar input {
  width:100%; border:2.5px solid #bdbdbd; border-radius:10px;
  padding:16px 22px; font-size:22px;
  font-family:'Inter',sans-serif; color:#1a1a1a;
  background:#fafafa; outline:none;
}
.filter-bar input:focus { border-color:#b71c1c; background:#fff; }
.filter-bar input::placeholder { color:#aaa; }
.filter-bar select {
  border:2.5px solid #bdbdbd; border-radius:10px;
  padding:16px 20px; font-size:21px;
  font-family:'Inter',sans-serif; color:#1a1a1a;
  background:#fafafa; outline:none; min-width:190px; cursor:pointer;
}
.filter-bar select:focus { border-color:#b71c1c; }
.btn-filter {
  background:#1a1a1a; border:none; color:#fff;
  border-radius:10px; padding:16px 32px;
  font-size:21px; font-weight:800; cursor:pointer;
  font-family:'Inter',sans-serif; display:flex; align-items:center; gap:8px;
  transition:background 0.2s;
}
.btn-filter:hover { background:#333; }
.btn-clear {
  background:#f5f5f5; border:2.5px solid #bdbdbd; color:#555;
  border-radius:10px; padding:16px 26px; font-size:21px; font-weight:700;
  text-decoration:none; transition:all 0.2s;
}
.btn-clear:hover { background:#e0e0e0; color:#1a1a1a; }

/* TABLE CARD */
.table-card {
  background:#fff; border-radius:16px;
  box-shadow:0 2px 10px rgba(0,0,0,0.07);
  overflow:hidden;
}
.table-top {
  padding:26px 32px; border-bottom:3px solid #f0f0f0;
  display:flex; align-items:center; justify-content:space-between;
}
.table-top h3 {
  font-size:28px; font-weight:900; color:#1a1a1a;
  display:flex; align-items:center; gap:12px;
}
.table-top h3 i { color:#b71c1c; }
.count-pill {
  background:#ffebee; color:#b71c1c; border-radius:30px;
  padding:6px 20px; font-size:22px; font-weight:800;
  margin-left:14px;
}
.table-scroll { overflow-x:auto; }
table { width:100%; border-collapse:collapse; min-width:1300px; }
thead tr { background:#1a1a1a; }
thead th {
  padding:22px 20px; font-size:20px; font-weight:800;
  color:#fff; text-transform:uppercase;
  letter-spacing:0.06em; text-align:left;
  white-space:nowrap; border:none;
}
tbody tr { border-bottom:2px solid #f0f0f0; }
tbody tr:hover { background:#fff8f8; }
tbody td { padding:24px 20px; vertical-align:middle; font-size:21px; }

/* Cell styles */
.id-cell   { color:#999; font-weight:700; font-size:20px; }
.title-main { font-weight:800; color:#1a1a1a; font-size:22px; line-height:1.4; }
.title-sub  { color:#999; font-size:18px; margin-top:6px; }

/* Badges */
.badge-type {
  background:#eceff1; color:#37474f;
  border-radius:8px; padding:9px 18px;
  font-size:20px; font-weight:800;
  display:inline-flex; align-items:center; gap:8px;
  white-space:nowrap;
}
.badge-sev {
  border-radius:30px; padding:9px 20px;
  font-size:20px; font-weight:900;
  display:inline-block; border:2.5px solid;
  white-space:nowrap;
}
.sev-CRITICAL { background:#ffebee; color:#b71c1c; border-color:#e53935; }
.sev-HIGH     { background:#fff3e0; color:#e65100; border-color:#fb8c00; }
.sev-MEDIUM   { background:#e3f2fd; color:#0d47a1; border-color:#1976d2; }
.sev-LOW      { background:#e8f5e9; color:#1b5e20; border-color:#388e3c; }

.badge-status {
  border-radius:30px; padding:9px 20px;
  font-size:20px; font-weight:900;
  display:inline-flex; align-items:center; gap:9px;
  border:2.5px solid; white-space:nowrap;
}
.st-ACTIVE     { background:#ffebee; color:#b71c1c; border-color:#e53935; }
.st-MONITORING { background:#fff8e1; color:#e65100; border-color:#ffc107; }
.st-RESOLVED   { background:#e8f5e9; color:#1b5e20; border-color:#388e3c; }
.blink { width:10px; height:10px; border-radius:50%; background:currentColor;
         animation:bl 1.4s infinite; display:inline-block; }
@keyframes bl { 0%,100%{opacity:1} 50%{opacity:.2} }

.loc-cell { color:#37474f; font-size:20px; font-weight:600; line-height:1.4; }
.aff-cell { font-weight:900; color:#1a1a1a; font-size:22px;
            display:flex; align-items:center; gap:8px; }
.aff-cell i { color:#1565c0; font-size:22px; }
.time-cell { color:#999; font-size:19px; white-space:nowrap; }

/* Action buttons */
.action-btns { display:flex; gap:10px; flex-wrap:nowrap; }
.ab {
  border-radius:10px; padding:11px 20px;
  font-size:19px; font-weight:800;
  text-decoration:none; border:2.5px solid;
  display:inline-flex; align-items:center; gap:7px;
  transition:all 0.15s; white-space:nowrap;
  font-family:'Inter',sans-serif; cursor:pointer;
}
.ab-v { color:#0d47a1; border-color:#1976d2; background:#e3f2fd; }
.ab-v:hover { background:#0d47a1; color:#fff; border-color:#0d47a1; }
.ab-e { color:#e65100; border-color:#fb8c00; background:#fff3e0; }
.ab-e:hover { background:#e65100; color:#fff; border-color:#e65100; }
.ab-d { color:#b71c1c; border-color:#e53935; background:#ffebee; }
.ab-d:hover { background:#b71c1c; color:#fff; border-color:#b71c1c; }

.empty-state { text-align:center; padding:80px 20px; }
.empty-state i { font-size:80px; color:#bdbdbd; display:block; margin-bottom:24px; }
.empty-state p { color:#9e9e9e; font-size:26px; font-weight:600; }
.empty-state a { color:#b71c1c; font-weight:800; }
</style>
</head>
<body>

<!-- NAVBAR -->
<div class="navbar">
  <div class="nav-left">
    <span class="nav-icon">🚨</span>
    <span class="nav-title">CrisisNet</span>
  </div>
  <div class="nav-right">
    <div class="officer-name">👤 &nbsp;<%= session.getAttribute("fullName") %></div>
    <a href="alerts?action=logout" class="btn-logout">
      <i class="bi bi-box-arrow-right"></i> Sign Out
    </a>
  </div>
</div>

<div class="page">

  <!-- PAGE HEADER -->
  <div class="page-hdr">
    <h2><i class="bi bi-speedometer2"></i> Command Dashboard</h2>
    <a href="alerts?action=new" class="btn-report">
      <i class="bi bi-plus-circle-fill"></i> Report New Alert
    </a>
  </div>

  <!-- STAT CARDS -->
  <div class="stat-grid">
    <div class="stat-card red">
      <div class="stat-emoji">🔴</div>
      <div>
        <div class="stat-num"><%= activeCount %></div>
        <div class="stat-lbl">Active Alerts</div>
      </div>
    </div>
    <div class="stat-card amber">
      <div class="stat-emoji">🟡</div>
      <div>
        <div class="stat-num"><%= monitoringCount %></div>
        <div class="stat-lbl">Monitoring</div>
      </div>
    </div>
    <div class="stat-card green">
      <div class="stat-emoji">✅</div>
      <div>
        <div class="stat-num"><%= resolvedCount %></div>
        <div class="stat-lbl">Resolved</div>
      </div>
    </div>
    <div class="stat-card blue">
      <div class="stat-emoji">👥</div>
      <div>
        <div class="stat-num"><%= String.format("%,d", totalAffected) %></div>
        <div class="stat-lbl">People Affected</div>
      </div>
    </div>
  </div>

  <!-- FILTER BAR -->
  <div class="filter-bar">
    <form action="alerts" method="get"
          style="display:flex;align-items:center;gap:20px;flex-wrap:wrap;width:100%">
      <input type="hidden" name="action" value="list">
      <div class="search-wrap">
        <input type="text" name="search"
               placeholder="🔍  Search by title, location, description..."
               value="<%= search != null ? search : "" %>">
      </div>
      <select name="type">
        <option value="">All Disaster Types</option>
        <% String[] types = {"FLOOD","FIRE","EARTHQUAKE","CYCLONE","LANDSLIDE","TSUNAMI","INDUSTRIAL","OTHER"};
           String[] tEmoji = {"🌊","🔥","⚡","🌀","⛰️","🌊","🏭","⚠️"};
           String ft = filterType != null ? filterType : "";
           for (int i=0;i<types.length;i++) { %>
        <option value="<%= types[i] %>" <%= types[i].equals(ft)?"selected":"" %>><%= tEmoji[i] %> <%= types[i] %></option>
        <% } %>
      </select>
      <select name="status">
        <option value="">All Statuses</option>
        <% String[] sts = {"ACTIVE","MONITORING","RESOLVED"};
           String[] sEmoji = {"🔴","🟡","🟢"};
           String fs = filterStatus != null ? filterStatus : "";
           for (int i=0;i<sts.length;i++) { %>
        <option value="<%= sts[i] %>" <%= sts[i].equals(fs)?"selected":"" %>><%= sEmoji[i] %> <%= sts[i] %></option>
        <% } %>
      </select>
      <button type="submit" class="btn-filter">
        <i class="bi bi-funnel-fill"></i> Filter
      </button>
      <a href="alerts" class="btn-clear">✕ Clear</a>
    </form>
  </div>

  <!-- TABLE -->
  <div class="table-card">
    <div class="table-top">
      <h3>
        <i class="bi bi-table"></i> All Disaster Alerts
        <span class="count-pill"><%= totalAlerts %> records</span>
      </h3>
      <span style="color:#999;font-size:20px;font-weight:600">
        <i class="bi bi-clock"></i> Latest first
      </span>
    </div>
    <div class="table-scroll">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Alert Title</th>
            <th>Type</th>
            <th>Severity</th>
            <th>Location</th>
            <th>Affected</th>
            <th>Status</th>
            <th>Reported At</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <%
            if (alerts != null && !alerts.isEmpty()) {
              for (Alert a : alerts) {
                String em = "⚠️";
                if ("FLOOD".equals(a.getDisasterType()))          em = "🌊";
                else if ("FIRE".equals(a.getDisasterType()))       em = "🔥";
                else if ("EARTHQUAKE".equals(a.getDisasterType())) em = "⚡";
                else if ("CYCLONE".equals(a.getDisasterType()))    em = "🌀";
                else if ("LANDSLIDE".equals(a.getDisasterType()))  em = "⛰️";
                else if ("TSUNAMI".equals(a.getDisasterType()))    em = "🌊";
                else if ("INDUSTRIAL".equals(a.getDisasterType())) em = "🏭";
          %>
          <tr>
            <td class="id-cell">#<%= a.getId() %></td>
            <td>
              <div class="title-main"><%= a.getTitle() %></div>
              <div class="title-sub">
                <i class="bi bi-person-badge"></i> <%= a.getReportedBy() %>
              </div>
            </td>
            <td>
              <span class="badge-type">
                <span style="font-size:22px"><%= em %></span>
                <%= a.getDisasterType() %>
              </span>
            </td>
            <td>
              <span class="badge-sev sev-<%= a.getSeverity() %>">
                <%= a.getSeverity() %>
              </span>
            </td>
            <td class="loc-cell"><%= a.getLocation() %></td>
            <td>
              <div class="aff-cell">
                <i class="bi bi-people-fill"></i>
                <%= String.format("%,d", a.getAffectedCount()) %>
              </div>
            </td>
            <td>
              <span class="badge-status st-<%= a.getStatus() %>">
                <span class="blink"></span>
                <%= a.getStatus() %>
              </span>
            </td>
            <td class="time-cell">
              <%= a.getReportedAt() != null ? a.getReportedAt().toString().substring(0,16) : "—" %>
            </td>
            <td>
              <div class="action-btns">
                <a href="alerts?action=view&id=<%= a.getId() %>" class="ab ab-v">
                  <i class="bi bi-eye-fill"></i> View
                </a>
                <a href="alerts?action=edit&id=<%= a.getId() %>" class="ab ab-e">
                  <i class="bi bi-pencil-fill"></i> Edit
                </a>
                <a href="alerts?action=delete&id=<%= a.getId() %>"
                   onclick="return confirm('Delete alert #<%= a.getId() %>?')"
                   class="ab ab-d">
                  <i class="bi bi-trash-fill"></i> Delete
                </a>
              </div>
            </td>
          </tr>
          <% } } else { %>
          <tr><td colspan="9">
            <div class="empty-state">
              <i class="bi bi-inbox"></i>
              <p>No alerts found. <a href="alerts?action=new">Report one now.</a></p>
            </div>
          </td></tr>
          <% } %>
        </tbody>
      </table>
    </div>
  </div>

</div>
</body>
</html>