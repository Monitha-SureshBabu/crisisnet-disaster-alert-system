<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280, initial-scale=1.0">
<title>CrisisNet — Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
html, body {
  height:100%; font-family:'Inter',sans-serif;
  background:#ffffff;
  display:flex; align-items:center; justify-content:center;
}
.login-box {
  background:#ffffff;
  border:3px solid #e0e0e0;
  border-radius:20px;
  padding:70px 90px;
  width:680px;
  box-shadow:0 12px 48px rgba(0,0,0,0.10);
}
.logo { text-align:center; margin-bottom:50px; }
.logo-icon { font-size:90px; display:block; margin-bottom:18px; }
.logo h1 { font-size:52px; font-weight:900; color:#b71c1c; margin-bottom:12px; }
.logo p  { font-size:24px; color:#555; font-weight:600; }

.err-box {
  background:#ffebee; border:2px solid #ef9a9a;
  border-left:6px solid #e53935;
  border-radius:10px; padding:20px 28px;
  color:#b71c1c; font-size:22px; font-weight:700;
  margin-bottom:36px;
}

.field-group { margin-bottom:36px; }
.field-group label {
  display:block; font-size:22px; font-weight:800;
  color:#1a1a1a; margin-bottom:14px; text-transform:uppercase;
  letter-spacing:0.04em;
}
.field-group input {
  width:100%; border:3px solid #bdbdbd; border-radius:12px;
  padding:22px 28px; font-size:24px;
  font-family:'Inter',sans-serif; color:#1a1a1a;
  background:#fafafa; outline:none; transition:border-color 0.2s;
}
.field-group input:focus {
  border-color:#e53935;
  background:#fff;
  box-shadow:0 0 0 5px rgba(229,57,53,0.10);
}
.field-group input::placeholder { color:#aaa; }

.btn-login {
  width:100%; background:#b71c1c; border:none;
  color:#fff; font-weight:900; padding:24px;
  border-radius:12px; font-size:26px;
  font-family:'Inter',sans-serif; cursor:pointer;
  margin-top:8px; transition:background 0.2s;
  letter-spacing:0.02em;
}
.btn-login:hover { background:#c62828; }
</style>
</head>
<body>
<div class="login-box">
  <div class="logo">
    <span class="logo-icon">🚨</span>
    <h1>CrisisNet</h1>
    <p>Emergency Management Portal</p>
  </div>

  <% String error = (String) request.getAttribute("error");
     if (error != null) { %>
  <div class="err-box">⚠ &nbsp;<%= error %></div>
  <% } %>

  <form action="login" method="post">
    <div class="field-group">
      <label>Username</label>
      <input type="text" name="username" placeholder="Enter your username" required autofocus>
    </div>
    <div class="field-group">
      <label>Password</label>
      <input type="password" name="password" placeholder="Enter your password" required>
    </div>
    <button type="submit" class="btn-login">Sign In</button>
  </form>
</div>
</body>
</html>