<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="com.crisis.model.Alert" %>
<%
  if (session.getAttribute("user") == null) { response.sendRedirect("login"); return; }
  Alert a = (Alert) request.getAttribute("alert");
  boolean isEdit = (a != null);
  String heroColor = isEdit ? "#e65100" : "#b71c1c";
%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280, initial-scale=1.0">
<title><%= isEdit ? "Edit Alert" : "Report Alert" %> — CrisisNet</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
html { font-size:18px; }
body { font-family:'Inter',sans-serif; background:#f5f5f5; color:#1a1a1a; }

.navbar {
  background:#b71c1c; padding:0 40px; height:80px;
  display:flex; align-items:center; justify-content:space-between;
  position:sticky; top:0; z-index:100;
  box-shadow:0 3px 12px rgba(0,0,0,0.15);
}
.nav-left  { display:flex; align-items:center; gap:16px; }
.nav-icon  { font-size:38px; }
.nav-title { color:#fff; font-size:32px; font-weight:900; }
.back-btn  {
  background:#fff; color:#b71c1c; border-radius:10px;
  padding:12px 28px; font-size:22px; font-weight:800;
  text-decoration:none; display:flex; align-items:center; gap:10px;
  transition:all 0.2s;
}
.back-btn:hover { background:#ffebee; color:#b71c1c; }

.page { padding:40px; }
.form-card {
  background:#fff; border-radius:18px;
  box-shadow:0 2px 14px rgba(0,0,0,0.09);
  overflow:hidden; max-width:1300px; margin:0 auto;
}

.form-hero {
  background:<%= heroColor %>;
  padding:44px 50px; color:#fff;
  display:flex; align-items:center; gap:28px;
}
.hero-icon {
  font-size:64px; background:rgba(255,255,255,0.15);
  border-radius:18px; padding:14px 20px;
  border:2px solid rgba(255,255,255,0.3);
}
.form-hero h2 { font-size:40px; font-weight:900; margin-bottom:10px; }
.form-hero p  { font-size:22px; opacity:0.88; margin:0; }

.form-body { padding:48px 50px; }

.section-title {
  font-size:24px; font-weight:900; color:#b71c1c;
  text-transform:uppercase; letter-spacing:0.06em;
  margin-bottom:30px; margin-top:14px;
  padding-bottom:14px; border-bottom:3px solid #ffebee;
  display:flex; align-items:center; gap:12px;
}
.section-title i { font-size:26px; }

.field-row { display:grid; gap:30px; margin-bottom:32px; }
.cols-1 { grid-template-columns:1fr; }
.cols-2 { grid-template-columns:1fr 1fr; }
.cols-3 { grid-template-columns:1fr 1fr 1fr; }

.field-group label {
  display:block; font-size:21px; font-weight:800; color:#1a1a1a;
  text-transform:uppercase; letter-spacing:0.04em; margin-bottom:12px;
}
.field-group input,
.field-group select,
.field-group textarea {
  width:100%; border:2.5px solid #bdbdbd; border-radius:12px;
  padding:18px 22px; font-size:22px;
  font-family:'Inter',sans-serif; color:#1a1a1a;
  background:#fafafa; outline:none; transition:all 0.2s;
}
.field-group input:focus,
.field-group select:focus,
.field-group textarea:focus {
  border-color:<%= heroColor %>;
  background:#fff;
  box-shadow:0 0 0 5px rgba(183,28,28,0.08);
}
.field-group input::placeholder,
.field-group textarea::placeholder { color:#bbb; }
.field-group textarea { resize:vertical; min-height:180px; line-height:1.75; }

.form-footer {
  padding:34px 50px; background:#f9f9f9;
  border-top:2.5px solid #f0f0f0;
  display:flex; align-items:center; gap:22px;
}
.btn-submit {
  background:<%= heroColor %>; border:none; color:#fff; font-weight:900;
  padding:20px 48px; border-radius:12px; font-size:26px;
  font-family:'Inter',sans-serif; cursor:pointer; transition:all 0.2s;
  display:flex; align-items:center; gap:12px;
}
.btn-submit:hover { opacity:0.9; }
.btn-cancel {
  background:#f5f5f5; border:2.5px solid #bdbdbd; color:#555;
  border-radius:12px; padding:20px 36px; font-size:24px; font-weight:800;
  text-decoration:none; display:flex; align-items:center; gap:10px;
  transition:all 0.2s; font-family:'Inter',sans-serif;
}
.btn-cancel:hover { background:#e0e0e0; color:#1a1a1a; }
.id-tag { margin-left:auto; color:#bbb; font-size:21px; font-weight:700; }
</style>
</head>
<body>

<div class="navbar">
  <div class="nav-left">
    <span class="nav-icon">🚨</span>
    <span class="nav-title">CrisisNet</span>
  </div>
  <a href="alerts" class="back-btn">
    <i class="bi bi-arrow-left"></i> Back to Dashboard
  </a>
</div>

<div class="page">
  <div class="form-card">
    <div class="form-hero">
      <div class="hero-icon"><%= isEdit ? "✏️" : "🚨" %></div>
      <div>
        <h2><%= isEdit ? "Edit Disaster Alert" : "Report New Disaster Alert" %></h2>
        <p><%= isEdit ? "Update the emergency information below." : "Log a new emergency alert into the system." %></p>
      </div>
    </div>

    <div class="form-body">
      <form action="alerts" method="post">
        <input type="hidden" name="action" value="<%= isEdit ? "edit" : "add" %>">
        <% if (isEdit) { %><input type="hidden" name="id" value="<%= a.getId() %>"><% } %>

        <div class="section-title">
          <i class="bi bi-info-circle-fill"></i> Basic Information
        </div>

        <div class="field-row cols-1">
          <div class="field-group">
            <label>Alert Title</label>
            <input type="text" name="title"
                   placeholder="e.g.  Severe Flooding in Coastal District"
                   value="<%= isEdit ? a.getTitle() : "" %>" required>
          </div>
        </div>

        <div class="field-row cols-3">
          <div class="field-group">
            <label>Disaster Type</label>
            <select name="disaster_type" required>
              <% String[] types = {"FLOOD","FIRE","EARTHQUAKE","CYCLONE","LANDSLIDE","TSUNAMI","INDUSTRIAL","OTHER"};
                 String[] tEm = {"🌊 ","🔥 ","⚡ ","🌀 ","⛰️ ","🌊 ","🏭 ","⚠️ "};
                 String curType = isEdit ? a.getDisasterType() : "";
                 for (int i=0;i<types.length;i++) { %>
              <option value="<%= types[i] %>" <%= types[i].equals(curType)?"selected":"" %>><%= tEm[i] %><%= types[i] %></option>
              <% } %>
            </select>
          </div>
          <div class="field-group">
            <label>Severity Level</label>
            <select name="severity" required>
              <% String[] sevs = {"CRITICAL","HIGH","MEDIUM","LOW"};
                 String[] sEm = {"🔴 ","🟠 ","🔵 ","🟢 "};
                 String curSev = isEdit ? a.getSeverity() : "HIGH";
                 for (int i=0;i<sevs.length;i++) { %>
              <option value="<%= sevs[i] %>" <%= sevs[i].equals(curSev)?"selected":"" %>><%= sEm[i] %><%= sevs[i] %></option>
              <% } %>
            </select>
          </div>
          <div class="field-group">
            <label>Current Status</label>
            <select name="status" required>
              <% String[] sts = {"ACTIVE","MONITORING","RESOLVED"};
                 String[] stEm = {"🔴 ","🟡 ","✅ "};
                 String curSt = isEdit ? a.getStatus() : "ACTIVE";
                 for (int i=0;i<sts.length;i++) { %>
              <option value="<%= sts[i] %>" <%= sts[i].equals(curSt)?"selected":"" %>><%= stEm[i] %><%= sts[i] %></option>
              <% } %>
            </select>
          </div>
        </div>

        <div class="field-row cols-2">
          <div class="field-group">
            <label>Affected Location</label>
            <input type="text" name="location"
                   placeholder="e.g.  Chennai South District, Tamil Nadu"
                   value="<%= isEdit ? a.getLocation() : "" %>" required>
          </div>
          <div class="field-group">
            <label>Estimated People Affected</label>
            <input type="number" name="affected_count" min="0"
                   placeholder="e.g.  5000"
                   value="<%= isEdit ? a.getAffectedCount() : "0" %>" required>
          </div>
        </div>

        <div class="section-title">
          <i class="bi bi-file-text-fill"></i> Situation Report
        </div>

        <div class="field-row cols-1">
          <div class="field-group">
            <label>Full Description</label>
            <textarea name="description"
              placeholder="Describe the current emergency — ongoing rescue operations, areas impacted, resources deployed..."><%= isEdit && a.getDescription() != null ? a.getDescription() : "" %></textarea>
          </div>
        </div>

      </div>

      <div class="form-footer">
        <button type="submit" class="btn-submit">
          <i class="bi bi-<%= isEdit ? "check-circle-fill" : "send-fill" %>"></i>
          <%= isEdit ? "Update Alert" : "Submit Alert Report" %>
        </button>
        <a href="alerts" class="btn-cancel">
          <i class="bi bi-x-circle"></i> Cancel
        </a>
        <% if (isEdit) { %>
        <span class="id-tag">Alert ID: #<%= a.getId() %></span>
        <% } %>
      </div>
      </form>
    </div>
  </div>
</div>
</body>
</html>