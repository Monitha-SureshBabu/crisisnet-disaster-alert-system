<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="com.crisis.model.Alert" %>
<%
  if (session.getAttribute("user") == null) { response.sendRedirect("login"); return; }
  Alert a = (Alert) request.getAttribute("alert");
  if (a == null) { response.sendRedirect("alerts"); return; }
  String em = "⚠️";
  if ("FLOOD".equals(a.getDisasterType()))          em = "🌊";
  else if ("FIRE".equals(a.getDisasterType()))       em = "🔥";
  else if ("EARTHQUAKE".equals(a.getDisasterType())) em = "⚡";
  else if ("CYCLONE".equals(a.getDisasterType()))    em = "🌀";
  else if ("LANDSLIDE".equals(a.getDisasterType()))  em = "⛰️";
  else if ("TSUNAMI".equals(a.getDisasterType()))    em = "🌊";
  else if ("INDUSTRIAL".equals(a.getDisasterType())) em = "🏭";
%>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=1280, initial-scale=1.0">
<title>Alert #<%= a.getId() %> — CrisisNet</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
html { font-size:18px; }
body { font-family:'Inter',sans-serif; background:#f5f5f5; color:#1a1a1a; }

.navbar {
  background:#b71c1c; padding:0 40px; height:80px;
  display:flex; align-items:center; justify-content:space-between;
  position:sticky; top:0; z-index:100;
  box-shadow:0 3px 12px rgba(0,0,0,0.15);
}
.nav-left  { display:flex; align-items:center; gap:16px; }
.nav-icon  { font-size:38px; }
.nav-title { color:#fff; font-size:32px; font-weight:900; }
.back-btn  {
  background:#fff; color:#b71c1c; border-radius:10px;
  padding:12px 28px; font-size:22px; font-weight:800;
  text-decoration:none; display:flex; align-items:center; gap:10px; transition:all 0.2s;
}
.back-btn:hover { background:#ffebee; color:#b71c1c; }

.page { padding:40px; max-width:1400px; margin:0 auto; }

.detail-wrap {
  background:#fff; border-radius:18px;
  box-shadow:0 2px 14px rgba(0,0,0,0.09); overflow:hidden;
}

/* HERO */
.detail-hero {
  background:#b71c1c; padding:48px 50px; color:#fff;
}
.hero-top { display:flex; align-items:flex-start; gap:30px; margin-bottom:30px; }
.hero-em  { font-size:90px; line-height:1; }
.hero-meta { flex:1; }
.hero-id { color:rgba(255,255,255,0.65); font-size:22px; font-weight:700; margin-bottom:12px; }
.hero-title { font-size:40px; font-weight:900; line-height:1.3; }
.hero-badges { display:flex; gap:16px; flex-wrap:wrap; }
.hb {
  background:rgba(255,255,255,0.2); color:#fff;
  border:2px solid rgba(255,255,255,0.35);
  border-radius:30px; padding:12px 28px;
  font-size:22px; font-weight:800;
  display:inline-flex; align-items:center; gap:10px;
}

/* INFO GRID */
.info-grid {
  display:grid; grid-template-columns:repeat(3,1fr);
  border-bottom:3px solid #f5f5f5;
}
.info-cell {
  padding:38px 42px; border-right:2px solid #f5f5f5;
}
.info-cell:last-child { border-right:none; }
.info-lbl {
  font-size:20px; font-weight:800; color:#9e9e9e;
  text-transform:uppercase; letter-spacing:0.06em;
  margin-bottom:16px; display:flex; align-items:center; gap:9px;
}
.info-lbl i { font-size:20px; color:#b71c1c; }
.info-val { font-size:26px; font-weight:800; color:#1a1a1a; }
.info-val.big {
  font-size:56px; font-weight:900; color:#b71c1c; line-height:1;
}
.badge-sev {
  border-radius:30px; padding:11px 24px; font-size:22px; font-weight:900;
  display:inline-block; border:2.5px solid;
}
.sev-CRITICAL { background:#ffebee; color:#b71c1c; border-color:#e53935; }
.sev-HIGH     { background:#fff3e0; color:#e65100; border-color:#fb8c00; }
.sev-MEDIUM   { background:#e3f2fd; color:#0d47a1; border-color:#1976d2; }
.sev-LOW      { background:#e8f5e9; color:#1b5e20; border-color:#388e3c; }
.badge-type   {
  background:#eceff1; color:#37474f; border-radius:10px;
  padding:10px 22px; font-size:22px; font-weight:800;
}

/* DESCRIPTION */
.desc-section { padding:42px 50px; border-bottom:3px solid #f5f5f5; }
.desc-lbl {
  font-size:22px; font-weight:900; color:#b71c1c;
  text-transform:uppercase; letter-spacing:0.06em;
  display:flex; align-items:center; gap:12px; margin-bottom:22px;
}
.desc-lbl i { font-size:24px; }
.desc-box {
  background:#fafafa; border:2.5px solid #e0e0e0; border-radius:14px;
  padding:32px; color:#37474f; line-height:1.85; font-size:22px; font-weight:500;
}

/* ACTION BAR */
.action-bar { padding:34px 50px; display:flex; align-items:center; gap:20px; flex-wrap:wrap; }
.btn-action {
  border:none; color:#fff; font-weight:900;
  padding:18px 36px; border-radius:12px; text-decoration:none;
  font-size:24px; display:flex; align-items:center; gap:12px;
  transition:all 0.2s; font-family:'Inter',sans-serif; cursor:pointer;
}
.btn-edit-a { background:#e65100; }
.btn-edit-a:hover { background:#bf360c; color:#fff; }
.btn-del-a  { background:#b71c1c; }
.btn-del-a:hover  { background:#c62828; color:#fff; }
.btn-back-a {
  background:#f5f5f5; border:2.5px solid #bdbdbd; color:#555;
  border-radius:12px; padding:18px 34px; font-size:24px; font-weight:800;
  text-decoration:none; display:flex; align-items:center; gap:12px;
  transition:all 0.2s; font-family:'Inter',sans-serif;
}
.btn-back-a:hover { background:#e0e0e0; color:#1a1a1a; }
</style>
</head>
<body>

<div class="navbar">
  <div class="nav-left">
    <span class="nav-icon">🚨</span>
    <span class="nav-title">CrisisNet</span>
  </div>
  <a href="alerts" class="back-btn">
    <i class="bi bi-arrow-left"></i> Back to Dashboard
  </a>
</div>

<div class="page">
  <div class="detail-wrap">

    <!-- HERO -->
    <div class="detail-hero">
      <div class="hero-top">
        <div class="hero-em"><%= em %></div>
        <div class="hero-meta">
          <div class="hero-id">
            Alert ID #<%= a.getId() %> &nbsp;•&nbsp; <%= a.getDisasterType() %> Disaster
          </div>
          <div class="hero-title"><%= a.getTitle() %></div>
        </div>
      </div>
      <div class="hero-badges">
        <span class="hb">
          <i class="bi bi-thermometer-high"></i> <%= a.getSeverity() %>
        </span>
        <span class="hb">
          <i class="bi bi-activity"></i> <%= a.getStatus() %>
        </span>
        <span class="hb">
          <i class="bi bi-geo-alt-fill"></i> <%= a.getLocation() %>
        </span>
      </div>
    </div>

    <!-- INFO GRID -->
    <div class="info-grid">
      <div class="info-cell">
        <div class="info-lbl"><i class="bi bi-people-fill"></i> People Affected</div>
        <div class="info-val big"><%= String.format("%,d", a.getAffectedCount()) %></div>
      </div>
      <div class="info-cell">
        <div class="info-lbl"><i class="bi bi-thermometer-half"></i> Severity</div>
        <div><span class="badge-sev sev-<%= a.getSeverity() %>"><%= a.getSeverity() %></span></div>
      </div>
      <div class="info-cell">
        <div class="info-lbl"><i class="bi bi-tag-fill"></i> Disaster Type</div>
        <div class="info-val">
          <span style="font-size:36px;vertical-align:middle;margin-right:10px"><%= em %></span>
          <span class="badge-type"><%= a.getDisasterType() %></span>
        </div>
      </div>
      <div class="info-cell">
        <div class="info-lbl"><i class="bi bi-person-badge-fill"></i> Reported By</div>
        <div class="info-val"><%= a.getReportedBy() %></div>
      </div>
      <div class="info-cell">
        <div class="info-lbl"><i class="bi bi-clock-fill"></i> Reported At</div>
        <div class="info-val">
          <%= a.getReportedAt() != null ? a.getReportedAt().toString().substring(0,16) : "—" %>
        </div>
      </div>
      <div class="info-cell">
        <div class="info-lbl"><i class="bi bi-arrow-clockwise"></i> Last Updated</div>
        <div class="info-val">
          <%= a.getUpdatedAt() != null ? a.getUpdatedAt().toString().substring(0,16) : "—" %>
        </div>
      </div>
    </div>

    <!-- DESCRIPTION -->
    <div class="desc-section">
      <div class="desc-lbl">
        <i class="bi bi-file-text-fill"></i> Situation Report
      </div>
      <div class="desc-box">
        <%= a.getDescription() != null && !a.getDescription().isEmpty()
            ? a.getDescription()
            : "<em style='color:#bdbdbd'>No situation report filed.</em>" %>
      </div>
    </div>

    <!-- ACTION BAR -->
    <div class="action-bar">
      <a href="alerts?action=edit&id=<%= a.getId() %>" class="btn-action btn-edit-a">
        <i class="bi bi-pencil-fill"></i> Edit Alert
      </a>
      <a href="alerts?action=delete&id=<%= a.getId() %>"
         onclick="return confirm('Permanently delete Alert #<%= a.getId() %>?')"
         class="btn-action btn-del-a">
        <i class="bi bi-trash-fill"></i> Delete Alert
      </a>
      <a href="alerts" class="btn-back-a">
        <i class="bi bi-grid-3x3-gap-fill"></i> Back to Dashboard
      </a>
    </div>

  </div>
</div>
</body>
</html>